
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import type { DragEndEvent } from '@dnd-kit/core';
import type { Student, SeatingChart, ViewMode, GroupSettings, Group, ArrangementMode, Row, Table } from './types';
import ControlsPanel from './components/ControlsPanel';
import SeatingChartDisplay from './components/SeatingChartDisplay';
import HelpModal from './components/HelpModal';
import StudentManagerModal from './components/StudentManagerModal'; // Now acts as a Page
import PriorityStudentsView from './components/PriorityStudentsView';
import NavBar from './components/NavBar';
import Login from './components/Login'; // Import Login component
import { supabase } from './supabaseClient';

// Fisher-Yates shuffle algorithm
const shuffleArray = <T,>(array: T[]): T[] => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

// Helper to calculate short names
const calculateShortNames = (students: Student[]): Student[] => {
  const shortNameCounts = new Map<string, number>();
  
  // First pass: count names
  students.forEach(s => {
      const nameParts = s.fullName.trim().split(' ');
      const baseShortName = nameParts[nameParts.length - 1];
      const currentCount = shortNameCounts.get(baseShortName) || 0;
      shortNameCounts.set(baseShortName, currentCount + 1);
  });

  // Second pass: assign short names (needs a reset map to track assignments)
  const assignedCounts = new Map<string, number>();
  
  return students.map(student => {
    const nameParts = student.fullName.trim().split(' ');
    const baseShortName = nameParts[nameParts.length - 1];
    
    const total = shortNameCounts.get(baseShortName) || 0;
    
    if (total > 1) {
        const assigned = assignedCounts.get(baseShortName) || 0;
        assignedCounts.set(baseShortName, assigned + 1);
        return { ...student, shortName: `${baseShortName} ${String.fromCharCode(64 + assigned + 1)}` };
    }
    return { ...student, shortName: baseShortName };
  });
};


export default function App() {
  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('seatflow_isLoggedIn') === 'true';
  });

  const [activeTab, setActiveTab] = useState<'chart' | 'manager' | 'priority'>('chart');
  const [isLoading, setIsLoading] = useState(true);
  
  // Settings & Data
  const [rows, setRows] = useState(4);
  const [cols, setCols] = useState(5);
  const [seatsPerTable, setSeatsPerTable] = useState(2);
  const [students, setStudents] = useState<Student[]>([]);
  const [studentListInput, setStudentListInput] = useState('');
  const [seatingChart, setSeatingChart] = useState<SeatingChart>([]);
  
  // UI State for Chart
  const [viewMode, setViewMode] = useState<ViewMode>('3d');
  const [rotation, setRotation] = useState({ x: 55, y: 0 });
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  
  // State for grouping feature
  const [groupSettings, setGroupSettings] = useState<GroupSettings>({
    enabled: false,
    groupSizes: [4, 4, 4],
    arrangement: 'horizontal',
  });
  const [groups, setGroups] = useState<Group[]>([]);
  const [groupLeaders, setGroupLeaders] = useState<Map<number, string>>(new Map());

  // State for arrangement mode
  const [arrangementMode, setArrangementMode] = useState<ArrangementMode>('automatic');

  // --- Auth Handlers ---
  const handleLogin = (isRemembered: boolean) => {
    setIsLoggedIn(true);
    if (isRemembered) {
      localStorage.setItem('seatflow_isLoggedIn', 'true');
    } else {
      localStorage.removeItem('seatflow_isLoggedIn');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('seatflow_isLoggedIn');
  };

  // --- Supabase Persistence Helpers ---
  const saveAppSettings = useCallback(async (updates: any) => {
    try {
        const { error } = await supabase
            .from('app_settings')
            .upsert({ id: 1, ...updates });
        if (error) console.error('Error saving settings:', error);
    } catch (err) {
        console.error('Exception saving settings:', err);
    }
  }, []);

  // --- Initial Data Fetching ---
  useEffect(() => {
    // Only fetch if logged in
    if (!isLoggedIn) return;

    const fetchData = async () => {
        setIsLoading(true);
        try {
            // 1. Fetch Settings
            const { data: settings, error: settingsError } = await supabase
                .from('app_settings')
                .select('*')
                .single();
            
            if (settings && !settingsError) {
                if (settings.rows) setRows(settings.rows);
                if (settings.cols) setCols(settings.cols);
                if (settings.seats_per_table) setSeatsPerTable(settings.seats_per_table);
                if (settings.student_list_input) setStudentListInput(settings.student_list_input);
                if (settings.seating_chart) setSeatingChart(settings.seating_chart);
                if (settings.group_settings) setGroupSettings(settings.group_settings);
                if (settings.groups_data) setGroups(settings.groups_data);
                if (settings.group_leaders) {
                     try {
                        const entries = Array.isArray(settings.group_leaders) ? settings.group_leaders : Object.entries(settings.group_leaders);
                        setGroupLeaders(new Map(entries.map((e: any) => [Number(e[0]), e[1]])));
                     } catch(e) { console.error("Error parsing group leaders", e)}
                }
                if (settings.arrangement_mode) setArrangementMode(settings.arrangement_mode as ArrangementMode);
            } else if (settingsError && settingsError.code !== 'PGRST116') { // Ignore "Row not found"
                console.error("Error fetching settings:", settingsError);
            }

            // 2. Fetch Students
            const { data: studentsData, error: studentsError } = await supabase
                .from('students')
                .select(`
                    id, 
                    full_name, 
                    short_name, 
                    parent_phone, 
                    address, 
                    weight,
                    height,
                    is_nearsighted,
                    is_special_needs,
                    current_seat_assigned_timestamp,
                    behavior_records (
                        id, type, description, score, timestamp
                    )
                `)
                .order('full_name');

            if (studentsData && !studentsError) {
                const mappedStudents: Student[] = studentsData.map((s: any) => ({
                    id: s.id,
                    fullName: s.full_name,
                    shortName: s.short_name || '',
                    currentSeatAssignedTimestamp: s.current_seat_assigned_timestamp ? Number(s.current_seat_assigned_timestamp) : null,
                    parentPhone: s.parent_phone,
                    address: s.address,
                    weight: s.weight,
                    height: s.height,
                    isNearsighted: s.is_nearsighted,
                    isSpecialNeeds: s.is_special_needs,
                    behaviorRecords: (s.behavior_records || []).map((br: any) => ({
                        ...br,
                        timestamp: Number(br.timestamp)
                    }))
                }));
                const withShortNames = calculateShortNames(mappedStudents);
                setStudents(withShortNames);
            }
        } catch (error) {
            console.error("Unexpected error loading data:", error);
        } finally {
            setIsLoading(false);
        }
    };
    fetchData();
  }, [isLoggedIn]);

  // --- Auto-save Effects ---
  useEffect(() => {
    if (isLoading || !isLoggedIn) return;
    const timer = setTimeout(() => {
        saveAppSettings({
            rows,
            cols,
            seats_per_table: seatsPerTable,
            group_settings: groupSettings,
        });
    }, 1000);
    return () => clearTimeout(timer);
  }, [rows, cols, seatsPerTable, groupSettings, isLoading, saveAppSettings, isLoggedIn]);

  const maxStudents = useMemo(() => rows * cols * seatsPerTable, [rows, cols, seatsPerTable]);

  // Handle syncing input text with DB
  const handleUpdateStudents = useCallback(async () => {
    if (isLoading) return;
    const names = studentListInput.split('\n').map(n => n.trim()).filter(n => n !== '');
    
    try {
        const { data: currentDbStudents } = await supabase.from('students').select('id, full_name');
        
        const existingMap = new Map();
        currentDbStudents?.forEach((s: any) => {
            if (!existingMap.has(s.full_name)) {
                existingMap.set(s.full_name, s);
            }
        });

        const promises = names.map(async (name) => {
             if (existingMap.has(name)) {
                 const existing = existingMap.get(name);
                 existingMap.delete(name); 
                 return existing;
             } else {
                 const { data, error } = await supabase
                    .from('students')
                    .insert({ full_name: name })
                    .select()
                    .single();
                 if (error) throw error;
                 return data;
             }
        });

        await Promise.all(promises);

        const { data: allStudents } = await supabase
            .from('students')
            .select(`*, behavior_records(*)`)
            .order('full_name');
        
        if (allStudents) {
            let mapped: Student[] = allStudents.map((s: any) => ({
                id: s.id,
                fullName: s.full_name,
                shortName: '', // will calc
                currentSeatAssignedTimestamp: s.current_seat_assigned_timestamp,
                parentPhone: s.parent_phone,
                address: s.address,
                weight: s.weight,
                height: s.height,
                isNearsighted: s.is_nearsighted,
                isSpecialNeeds: s.is_special_needs,
                behaviorRecords: s.behavior_records || []
            }));
            
            mapped = calculateShortNames(mapped);
            
            const updates = mapped.map(s => supabase.from('students').update({ short_name: s.shortName }).eq('id', s.id));
            await Promise.all(updates);

            setStudents(mapped);
            setSeatingChart([]);
            setGroups([]);
            setGroupLeaders(new Map());
            
            saveAppSettings({ 
                student_list_input: studentListInput,
                seating_chart: [],
                groups_data: [],
                group_leaders: {}
            });
        }
        alert("Đã cập nhật danh sách học sinh thành công!");
    } catch (error) {
        console.error("Error updating students:", error);
        alert("Có lỗi xảy ra khi cập nhật danh sách.");
    }
  }, [studentListInput, isLoading, saveAppSettings]);


  const handleUpdateSingleStudent = useCallback(async (updatedStudent: Student) => {
    setStudents(prev => prev.map(s => s.id === updatedStudent.id ? updatedStudent : s));
    
    const updateChart = (chart: SeatingChart) => chart.map(row => 
        row.map(table => 
            table.map(s => s.id === updatedStudent.id ? updatedStudent : s)
        )
    );
    setSeatingChart(prev => updateChart(prev));
    
    try {
        await supabase.from('students').update({
            parent_phone: updatedStudent.parentPhone,
            address: updatedStudent.address,
            weight: updatedStudent.weight,
            height: updatedStudent.height,
            is_nearsighted: updatedStudent.isNearsighted,
            is_special_needs: updatedStudent.isSpecialNeeds
        }).eq('id', updatedStudent.id);
    } catch(e) {
        console.error("Error saving student profile", e);
    }
  }, []);

  const handleApplyGrouping = useCallback((currentChart?: SeatingChart) => {
    if (arrangementMode === 'manual') {
      alert("Không thể chia tổ ở chế độ sắp xếp thủ công. Vui lòng chuyển sang chế độ Tự động.");
      return;
    }
    const chartToUse = currentChart || seatingChart;
    if (chartToUse.length === 0) {
      alert("Vui lòng sắp xếp lớp học trước khi chia tổ.");
      return;
    }
    const { groupSizes, arrangement } = groupSettings;
    const newGroups: Group[] = [];
    
    const allTableCoords: { rowIndex: number; colIndex: number }[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        allTableCoords.push({ rowIndex: r, colIndex: c });
      }
    }

    if (arrangement === 'cluster') {
        const isGrouped = Array(rows).fill(null).map(() => Array(cols).fill(false));
        for (let r = 0; r < rows - 1; r++) {
            for (let c = 0; c < cols - 1; c++) {
                if (!isGrouped[r][c] && !isGrouped[r][c+1] && !isGrouped[r+1][c] && !isGrouped[r+1][c+1]) {
                    newGroups.push([
                        { rowIndex: r, colIndex: c },
                        { rowIndex: r, colIndex: c + 1 },
                        { rowIndex: r + 1, colIndex: c },
                        { rowIndex: r + 1, colIndex: c + 1 },
                    ]);
                    isGrouped[r][c] = true; isGrouped[r][c+1] = true; isGrouped[r+1][c] = true; isGrouped[r+1][c+1] = true;
                }
            }
        }
        const remainingTables: Group = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                if (!isGrouped[r][c]) remainingTables.push({ rowIndex: r, colIndex: c });
            }
        }
        if (remainingTables.length > 0) newGroups.push(remainingTables);
    } else { 
        let orderedCoords: { rowIndex: number; colIndex: number }[] = [];
        if (arrangement === 'vertical') {
            for (let c = 0; c < cols; c++) {
                for (let r = 0; r < rows; r++) orderedCoords.push({ rowIndex: r, colIndex: c });
            }
        } else { // 'horizontal'
            orderedCoords = allTableCoords;
        }

        let currentIndex = 0;
        for (const size of groupSizes) {
            if (currentIndex >= orderedCoords.length || size <= 0) continue;
            const group = orderedCoords.slice(currentIndex, currentIndex + size);
            if (group.length > 0) newGroups.push(group);
            currentIndex += size;
        }
    }

    setGroups(newGroups);
    setGroupLeaders(new Map());
    saveAppSettings({ groups_data: newGroups, group_leaders: {} });
  }, [seatingChart, rows, cols, groupSettings, arrangementMode, saveAppSettings]);

  const handleInitialArrangement = useCallback(async () => {
    if (students.length === 0) {
      alert("Vui lòng nhập danh sách học sinh trước.");
      return;
    }

    const timestamp = Date.now();

    // --- SORTING ALGORITHM WITH PRIORITY ---
    
    // Bucket 1: Special Needs (Priority: Highest - Always Row 1)
    const specialNeeds = students.filter(s => s.isSpecialNeeds);
    
    // Bucket 2: Nearsighted OR Short Stature (< 135cm) (Priority: Medium - Row 1, 2)
    const priorityHealth = students.filter(s => {
        if (s.isSpecialNeeds) return false; // Already in Bucket 1
        const isShort = s.height && parseInt(s.height) < 135;
        return s.isNearsighted || isShort;
    });

    // Bucket 3: Everyone else
    const normalStudents = students.filter(s => {
        if (s.isSpecialNeeds) return false;
        const isShort = s.height && parseInt(s.height) < 135;
        return !s.isNearsighted && !isShort;
    });

    // Shuffle each bucket independently
    const shuffledSpecial = shuffleArray(specialNeeds);
    const shuffledPriority = shuffleArray(priorityHealth);
    const shuffledNormal = shuffleArray(normalStudents);

    // Combine them in order. 
    // The chart filling logic fills Row 0 first, then Row 1, etc.
    // So putting them in this order guarantees top rows for higher priority.
    const sortedStudents = [...shuffledSpecial, ...shuffledPriority, ...shuffledNormal];

    const newChart: SeatingChart = [];
    let studentIndex = 0;

    for (let i = 0; i < rows; i++) {
      const newRow: (Student[])[] = [];
      for (let j = 0; j < cols; j++) {
        const newTable: Student[] = [];
        for (let k = 0; k < seatsPerTable; k++) {
          if (studentIndex < sortedStudents.length) {
            newTable.push(sortedStudents[studentIndex]);
            studentIndex++;
          }
        }
        newRow.push(newTable);
      }
      newChart.push(newRow);
    }
    
    const flatStudents: Student[] = [];
    newChart.forEach(row => row.forEach(table => table.forEach(s => flatStudents.push(s))));
    const seatedStudentIds = new Set(flatStudents.map(s => s.id));
    
    const updatedStudents = students.map(student => 
      seatedStudentIds.has(student.id)
        ? { ...student, currentSeatAssignedTimestamp: timestamp }
        : { ...student, currentSeatAssignedTimestamp: null }
    );

    const updatedStudentMap = new Map(updatedStudents.map(s => [s.id, s]));
    
    const finalChartWithUpdates = newChart.map(row => 
      row.map(table => 
        table.map(student => updatedStudentMap.get(student.id)!)
      )
    );

    setStudents(updatedStudents);
    setSeatingChart(finalChartWithUpdates);
    
    await saveAppSettings({ 
        seating_chart: finalChartWithUpdates,
        student_list_input: studentListInput 
    });

    await supabase.from('students').upsert(updatedStudents.map(s => ({
        id: s.id,
        current_seat_assigned_timestamp: s.currentSeatAssignedTimestamp
    })));
    
    if(groupSettings.enabled) {
      handleApplyGrouping(finalChartWithUpdates);
    }

  }, [students, rows, cols, seatsPerTable, groupSettings.enabled, handleApplyGrouping, saveAppSettings, studentListInput]);
  
  const handleRotateSeats = useCallback(async () => {
    if (seatingChart.length < 2) {
      alert("Cần ít nhất 2 hàng để thực hiện luân chuyển.");
      return;
    }
    const timestamp = Date.now();

    // 1. Collect all students currently on the chart with their latest data
    const currentSeatedStudents: Student[] = [];
    seatingChart.forEach(row => {
        row.forEach(table => {
            table.forEach(s => {
                // Find latest data
                const latest = students.find(st => st.id === s.id) || s;
                currentSeatedStudents.push(latest);
            });
        });
    });

    // 2. Separate into buckets
    const poolSpecial: Student[] = [];
    const poolPriority: Student[] = [];
    const poolNormal: Student[] = [];

    currentSeatedStudents.forEach(s => {
        if (s.isSpecialNeeds) {
            poolSpecial.push(s);
        } else {
             // Check priority criteria: Nearsighted or Height < 135
             const isShort = s.height ? parseInt(s.height) < 135 : false;
             if (s.isNearsighted || isShort) {
                 poolPriority.push(s);
             } else {
                 poolNormal.push(s);
             }
        }
    });

    // 3. Process Pools
    // Shuffle Special & Priority to keep them fresh but in-zone
    const shuffledSpecial = shuffleArray(poolSpecial);
    const shuffledPriority = shuffleArray(poolPriority);

    // Rotate Normal: Move top chunk to bottom
    // To be deterministic and noticeable, use Cols * SeatsPerTable (approx 1 row)
    const rotateChunkSize = Math.max(1, cols * seatsPerTable);
    
    let rotatedNormal: Student[] = [];
    if (poolNormal.length > 0) {
        const actualShift = rotateChunkSize % poolNormal.length; // Handle small pools
        // Move front to back
        rotatedNormal = [
            ...poolNormal.slice(actualShift),
            ...poolNormal.slice(0, actualShift)
        ];
    }

    // 4. Create Fill Queue: Special -> Priority -> Normal
    // This order guarantees Special fills Row 0 first.
    // Then Priority fills remaining Row 0 and Row 1 (and potentially Row 2 if many).
    // Then Normal fills the rest.
    const fillQueue = [...shuffledSpecial, ...shuffledPriority, ...rotatedNormal];
    
    // 5. Reconstruct Chart
    const newChart: SeatingChart = [];
    let queueIndex = 0;

    for (let r = 0; r < rows; r++) {
        const newRow: Row = [];
        for (let c = 0; c < cols; c++) {
            const newTable: Table = [];
            for (let s = 0; s < seatsPerTable; s++) {
                if (queueIndex < fillQueue.length) {
                    newTable.push(fillQueue[queueIndex]);
                    queueIndex++;
                }
            }
            newRow.push(newTable);
        }
        newChart.push(newRow);
    }

    // 6. Save and Update State
    const flatFinalStudents: Student[] = [];
    newChart.forEach(row => row.forEach(table => table.forEach(s => flatFinalStudents.push(s))));

    const seatedStudentIds = new Set(flatFinalStudents.map(s => s.id));
    const updatedStudents = students.map(student => 
      seatedStudentIds.has(student.id) ? { ...student, currentSeatAssignedTimestamp: timestamp } : student
    );
    const updatedStudentMap = new Map(updatedStudents.map(s => [s.id, s]));
    
    const finalChartWithUpdates = newChart.map(row => 
      row.map(table => table.map(student => updatedStudentMap.get(student.id)!))
    );

    setStudents(updatedStudents);
    setSeatingChart(finalChartWithUpdates);
    
    await saveAppSettings({ seating_chart: finalChartWithUpdates });
    await supabase.from('students').upsert(updatedStudents.map(s => ({ id: s.id, current_seat_assigned_timestamp: s.currentSeatAssignedTimestamp })));

    if(groupSettings.enabled) {
      handleApplyGrouping(finalChartWithUpdates);
    }

  }, [seatingChart, students, groupSettings.enabled, handleApplyGrouping, saveAppSettings, rows, cols, seatsPerTable]);

  const handleSetGroupLeader = useCallback((groupIndex: number, studentId: string) => {
    setGroupLeaders(prev => {
        const newLeaders = new Map(prev);
        newLeaders.set(groupIndex, studentId);
        saveAppSettings({ group_leaders: Array.from(newLeaders.entries()) });
        return newLeaders;
    });
  }, [saveAppSettings]);

  const handleDragEnd = (event: DragEndEvent) => {
      const { active, over } = event;
      if (!over || active.id === over.id) return;
      
      setArrangementMode('manual');
      saveAppSettings({ arrangement_mode: 'manual' });

      const activeId = active.id.toString();
      const overId = over.id.toString();

      if (activeId.startsWith('table-') && overId.startsWith('table-')) {
          handleTableDragEnd(activeId, overId);
      } else if (activeId.startsWith('student-') && overId.startsWith('student-')) {
          handleStudentSwap(activeId, overId);
      } else if (activeId.startsWith('student-') && overId.startsWith('table-')) {
          handleStudentMoveToTable(activeId, overId);
      }
  };
  
  const handleTableDragEnd = (activeId: string, overId: string) => {
      const [, startRow, startCol] = activeId.split('-').map(Number);
      const [, endRow, endCol] = overId.split('-').map(Number);

      const newChart: SeatingChart = JSON.parse(JSON.stringify(seatingChart));
      const temp = newChart[startRow][startCol];
      newChart[startRow][startCol] = newChart[endRow][endCol];
      newChart[endRow][endCol] = temp;
      setSeatingChart(newChart);
      saveAppSettings({ seating_chart: newChart });
  };
  
  const findStudentPosition = (studentId: string) => {
      for (let r = 0; r < seatingChart.length; r++) {
          for (let c = 0; c < seatingChart[r].length; c++) {
              for (let s = 0; s < seatingChart[r][c].length; s++) {
                  if (`student-${seatingChart[r][c][s].id}` === studentId) {
                      return { r, c, s, student: seatingChart[r][c][s] };
                  }
              }
          }
      }
      return null;
  };

  const handleStudentSwap = (activeId: string, overId: string) => {
      const startPos = findStudentPosition(activeId);
      const endPos = findStudentPosition(overId);

      if (startPos && endPos) {
          const newChart: SeatingChart = JSON.parse(JSON.stringify(seatingChart));
          newChart[startPos.r][startPos.c][startPos.s] = endPos.student;
          newChart[endPos.r][endPos.c][endPos.s] = startPos.student;
          setSeatingChart(newChart);
          saveAppSettings({ seating_chart: newChart });
      }
  };

  const handleStudentMoveToTable = (activeId: string, overId: string) => {
      const startPos = findStudentPosition(activeId);
      const [, endRow, endCol] = overId.split('-').map(Number);
      
      if (startPos && seatingChart[endRow][endCol].length < seatsPerTable) {
          const newChart: SeatingChart = JSON.parse(JSON.stringify(seatingChart));
          newChart[startPos.r][startPos.c].splice(startPos.s, 1);
          newChart[endRow][endCol].push(startPos.student);
          setSeatingChart(newChart);
          saveAppSettings({ seating_chart: newChart });
      }
  };


  const handleExportJson = useCallback(() => {
    const seatingChartOfIds = seatingChart.map(row => 
      row.map(table => 
        table.map(student => student.id)
      )
    );
    const exportData = {
      seatflow_version: 1,
      exportDate: new Date().toLocaleString('vi-VN'),
      settings: { rows, cols, seatsPerTable },
      studentListInput,
      students,
      seatingChart: seatingChartOfIds,
      groupSettings,
      groups,
      groupLeaders: Array.from(groupLeaders.entries()),
      arrangementMode,
      ui: { viewMode, rotation }
    };
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', 'seatflow_backup.json');
    linkElement.click();
  }, [rows, cols, seatsPerTable, studentListInput, students, seatingChart, groupSettings, groups, groupLeaders, arrangementMode, viewMode, rotation]);

  const handleImportJson = useCallback(async (jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      if (data.seatflow_version !== 1) { alert("Phiên bản tệp không tương thích."); return; }
      
      setRows(data.settings.rows);
      setCols(data.settings.cols);
      setSeatsPerTable(data.settings.seatsPerTable);
      setStudentListInput(data.studentListInput);

      const importedStudents = data.students as Student[];
      setStudents(importedStudents);
      
      setGroupSettings(data.groupSettings);
      setGroups(data.groups);
      setGroupLeaders(new Map(data.groupLeaders));
      setArrangementMode(data.arrangementMode);

      const studentMap = new Map<string, Student>();
      importedStudents.forEach(s => studentMap.set(s.id, s));

      const rawSeatingChart = data.seatingChart as string[][][];
      const newSeatingChart: SeatingChart = rawSeatingChart.map((row) => 
        row.map((table) => 
          table.map((studentId) => studentMap.get(studentId))
               .filter((student): student is Student => student !== undefined)
        )
      );
      setSeatingChart(newSeatingChart);
      
      alert("Đã tải trạng thái.");

    } catch (error) {
      console.error("Lỗi khi nhập tệp JSON:", error);
      alert("Lỗi tệp JSON.");
    }
  }, []);

  const handleExportCsv = useCallback(() => {
    if (seatingChart.length === 0) { alert("Sơ đồ lớp học trống."); return; }
    const cols = seatingChart[0].length;
    let csvContent = "\uFEFF"; 
    csvContent += "SƠ ĐỒ LỚP HỌC\r\n";
    csvContent += `Ngày xuất: ${new Date().toLocaleString('vi-VN')}\r\n\r\n`;
    const topRow = new Array(cols).fill('');
    const podiumPosition = Math.floor(cols / 2);
    topRow[podiumPosition] = "BỤC GIẢNG";
    if (cols > 1) topRow[cols - 1] = "CỬA LỚP"; else topRow[0] += " / CỬA LỚP";
    csvContent += topRow.map(cell => `"${cell}"`).join(',') + '\r\n';
    csvContent += new Array(cols).fill('""').join(',') + '\r\n';
    seatingChart.forEach((row, rowIndex) => {
      const rowData = row.map((table, tableIndex) => {
        const tableNumber = (rowIndex * cols) + (cols - tableIndex);
        const studentNames = table.map(student => student.fullName).join("\n");
        const cellContent = `Bàn ${tableNumber}\n${studentNames}`;
        return `"${cellContent.trim()}"`;
      }).join(',');
      csvContent += rowData + "\r\n";
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "so_do_lop_hoc.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [seatingChart]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));

  // Conditionally render Login screen
  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  if (isLoading) {
      return <div className="flex h-screen w-full items-center justify-center bg-slate-100 text-slate-500">Đang tải dữ liệu từ Supabase...</div>;
  }

  // Render content based on Active Tab
  const renderContent = () => {
      switch (activeTab) {
          case 'chart':
              return (
                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                    <div className="flex flex-col md:flex-row h-full">
                        <ControlsPanel
                        rows={rows} setRows={setRows}
                        cols={cols} setCols={setCols}
                        seatsPerTable={seatsPerTable} setSeatsPerTable={setSeatsPerTable}
                        studentListInput={studentListInput} setStudentListInput={setStudentListInput}
                        students={students} maxStudents={maxStudents}
                        onUpdateStudents={handleUpdateStudents}
                        onInitialArrangement={handleInitialArrangement}
                        onRotateSeats={handleRotateSeats}
                        onExportJson={handleExportJson} onImportJson={handleImportJson}
                        onExportCsv={handleExportCsv}
                        onOpenHelp={() => setIsHelpModalOpen(true)}
                        groupSettings={groupSettings} setGroupSettings={setGroupSettings}
                        onApplyGrouping={() => handleApplyGrouping()}
                        arrangementMode={arrangementMode} setArrangementMode={setArrangementMode}
                        />
                        <main className="flex-1 flex flex-col p-4 md:p-6 lg:p-8 overflow-auto">
                        <SeatingChartDisplay
                            seatingChart={seatingChart}
                            viewMode={viewMode} setViewMode={setViewMode}
                            rotation={rotation} setRotation={setRotation}
                            groups={groups} groupLeaders={groupLeaders}
                            onSetGroupLeader={handleSetGroupLeader}
                            arrangementMode={arrangementMode} seatsPerTable={seatsPerTable}
                        />
                        </main>
                    </div>
                    <HelpModal isOpen={isHelpModalOpen} onClose={() => setIsHelpModalOpen(false)} />
                </DndContext>
              );
          case 'manager':
              return (
                <StudentManagerModal 
                    students={students}
                    onUpdateStudent={handleUpdateSingleStudent}
                />
              );
          case 'priority':
              return (
                  <PriorityStudentsView students={students} />
              );
          default:
              return null;
      }
  }

  return (
    <div className="flex flex-col h-screen bg-slate-100 text-slate-800 font-sans">
      <NavBar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="flex-1 overflow-hidden relative">
        {renderContent()}
      </div>
    </div>
  );
}
