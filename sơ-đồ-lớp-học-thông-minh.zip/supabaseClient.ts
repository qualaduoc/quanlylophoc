import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://nvswmkqweyisjzvlpogm.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im52c3dta3F3ZXlpc2p6dmxwb2dtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUyNjA3NjgsImV4cCI6MjA4MDgzNjc2OH0.yYh_BmfyyIIHRvV6nFFH-XQyeAC1_Z3nvJNjl51GOo0';

export const supabase = createClient(supabaseUrl, supabaseKey);
