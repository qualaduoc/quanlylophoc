
import React from 'react';
import { UserIcon } from './icons/UserIcon';
import { StarIcon } from './icons/StarIcon';

interface NavBarProps {
  activeTab: 'chart' | 'manager' | 'priority';
  onTabChange: (tab: 'chart' | 'manager' | 'priority') => void;
}

const NavBar: React.FC<NavBarProps> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between shadow-sm sticky top-0 z-50">
      <div className="flex items-center gap-3">
        <div className="bg-indigo-600 text-white p-2 rounded-lg">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>
        </div>
        <div>
           <h1 className="text-lg font-bold text-slate-800 leading-tight">SeatFlow</h1>
           <p className="text-xs text-slate-500">THCS Mường Thanh</p>
        </div>
      </div>

      <div className="flex bg-slate-100 p-1 rounded-lg overflow-x-auto">
        <button
          onClick={() => onTabChange('chart')}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-all whitespace-nowrap ${
            activeTab === 'chart'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2" /><line x1="3" y1="9" x2="21" y2="9" /><line x1="9" y1="21" x2="9" y2="9" /></svg>
          Sơ đồ lớp học
        </button>
        <button
          onClick={() => onTabChange('priority')}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-all whitespace-nowrap ${
            activeTab === 'priority'
              ? 'bg-white text-orange-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <StarIcon />
          Học sinh ưu tiên
        </button>
        <button
          onClick={() => onTabChange('manager')}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold transition-all whitespace-nowrap ${
            activeTab === 'manager'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <UserIcon />
          Quản lý học sinh
        </button>
      </div>

      <div className="hidden md:block w-32">
         {/* Spacer to balance the logo */}
      </div>
    </nav>
  );
};

export default NavBar;
